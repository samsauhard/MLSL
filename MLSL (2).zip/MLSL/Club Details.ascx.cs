﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Club_Details : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public String gset_city{

        get
        {
          return  city_input.Text;
         }
        
        set
        {
            city_input.Text = value;
        }

        }



    public String gset_name
    {

        get
        {
            return name_input.Text;
        }
        set
        {
            name_input.Text = value;
        }




    }
}