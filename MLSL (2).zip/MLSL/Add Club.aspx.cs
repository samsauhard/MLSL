﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Add_Club : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }




    



    protected void save_club_Click(object sender, EventArgs e)
    {
        Club_Repository repo = (Club_Repository)Application["repo_object"];
        Club newClub = new Club();
        newClub.setData(ClubDetails.gset_name, ClubDetails.gset_city, registration_number.Text, address.Text);
        repo.ClubData.Add(newClub);
        Application["repo_object"] = repo;
        Panel2.Visible = true;

    }



    protected void cancel_club_Click(object sender, EventArgs e)
    {

        ClubDetails.gset_name ="";
        ClubDetails.gset_city = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
    protected void cancel_player_Click(object sender, EventArgs e)
    {

        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";


    }

    protected void save_player_Click(object sender, EventArgs e)
    {
        Club_Repository repo = (Club_Repository)Application["repo_object"];
        Player newPlayer = new Player();
       // newPlayer.setData(Convert.ToInt32(TextBox5.Text),TextBox6.Text,TextBox7.Text);
        //repo.ClubData[repo.ClubData.Count()-1].Players.Add(newPlayer);
        //Application["repo_object"] = repo;
    }
}