﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Setup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }

    HttpCookie coo;
    protected void Page_PreInit(object sender, EventArgs e)
    {

        coo = Request.Cookies["coo"];
        if (coo != null)
        {
            string alright = coo.Value;

            if (alright == "Dark")
            {
                Page.Theme = "Dark";
            }
            else if (alright == "Light")
            {
                Page.Theme = "Light";
            }
        }
        else
        {
            Page.Theme = "Light";
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButton1.Checked == true)
        {

            coo = new HttpCookie("coo");
            coo.Value = "Light";
            coo.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Add(coo);
            Response.Redirect(Request.RawUrl);
        }
        else if (RadioButton2.Checked == true)
        {


            coo = new HttpCookie("cookie");
            coo.Value = "DarkTheme";
            coo.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Add(coo);
            Response.Redirect(Request.RawUrl);
        }
    }
}