﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clubs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Club_Repository cre = (Club_Repository)Application["repo_object"];
        this.Repeater1.DataSource = cre.ClubData;
        this.Repeater1.DataBind();
        


    }

    
}