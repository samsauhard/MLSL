﻿//Student Name: SAUHARD
//Student Id : 300986150
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class clubdetails : System.Web.UI.Page
{

    //Declaration of SQL Connection,Reader and Command
    SqlConnection conn;
    SqlCommand comm;
    SqlDataReader reader;

    //Executes When Page Loads
    protected void Page_Load(object sender, EventArgs e)
    {
        //Fetching Registration ID from Club Page Redirection URL
        String s = Request.QueryString["club"];

        //If requested page is not a Postback Request, Then fetch values from database 
        if (!IsPostBack)
        {

            //To Create Database Connection
            BindList();

            //Sql Query Stored in SqlCommand instance
            comm = new SqlCommand("SELECT * FROM Clubs where registration_number = @id", conn);
            comm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
            comm.Parameters["@id"].Value = s;
            conn.Open();
            reader = comm.ExecuteReader();

            //Assigning Data source to Data List
            this.clubsDetailedList.DataSource = reader;

            //Binding Data to Data List
            this.clubsDetailedList.DataBind();

            reader.Close();
            conn.Close();

            //To Create Database Connection
            BindList();

            comm = new SqlCommand("SELECT * FROM Players where club_registration_number = @id", conn);
            comm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
            comm.Parameters["@id"].Value = s;
            conn.Open();
            reader = comm.ExecuteReader();

            //Assigning Data Source to Grid View
            GridView1.DataSource = reader;

            //Binding Data to Grid View
            GridView1.DataBind();

            reader.Close();
            conn.Close();
        }
    }
    


    protected void clubDetailedListDisplay(object source, DataListCommandEventArgs e)
    {
        // Which button was clicked?
        if (e.CommandName == "deleteClub")
        {
            BindList();

            //Deleting Club Data
            comm = new SqlCommand("delete from Clubs where registration_number=@id ", conn); 
            comm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
            comm.Parameters["@id"].Value = e.CommandArgument;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
            conn.Open();
            comm.ExecuteScalar();
            conn.Close();

            //Deleting all the Players Associated with Club
            comm = new SqlCommand("delete from players where club_registration_number=@id ", conn);
            comm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
            comm.Parameters["@id"].Value = e.CommandArgument;
            conn.Open();
            comm.ExecuteScalar();
            conn.Close();


            //Deleting Club Matches
            comm = new SqlCommand("delete from matches where homeid=@id or awayid=@id ", conn);
            comm.Parameters.Add("@id", System.Data.SqlDbType.VarChar);
            comm.Parameters["@id"].Value = e.CommandArgument;
            conn.Open();
            comm.ExecuteScalar();
            conn.Close();

            //Redirects to Clubs Page
            Response.Redirect("Clubs.aspx");
        }
        else if (e.CommandName == "goBack")
        {
            //Redirects to Clubs Page
            Response.Redirect("Clubs.aspx");
        }

    }

    void BindList()
    {
        String connectionString = ConfigurationManager.ConnectionStrings["ClubConnection"].ConnectionString;
        conn = new SqlConnection(connectionString);
    }

   

}